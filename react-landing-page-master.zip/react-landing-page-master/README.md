# Quick and Simple React Landing Page

This is a very simple react landing page for easy manipulation and use. <br />
Check out the demo [here](https://react-landing-page-two.now.sh/)

## Getting Started

Clone the repository:

```
git clone https://github.com/000kelvin/react-landing-page.git
```

Run in Local Environment:

```
npm install

npm start
```

Run in Production:

```
npm build
```

## Contributions

Pull requests are welcome. For major changes, please open an issue first to discuss what you would like to change.

